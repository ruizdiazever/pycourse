#  Este es un modulo con funciones y clases que saludan:

def saludar(): # Funcion llamada 'saludar'
    print("Hola, te saludo desde una funcion del modulo <saludos> del subpaquete <hola>")

class Saludo(): # Clase llamada 'Saludo'
    def __init__(self):
        print("Hola, ahora saludo desde una clase del modulo <saludos> del subpaquete <hola>")