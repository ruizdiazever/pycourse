#  Este es un modulo con funciones y clases que despiden:

def despedir(): # Funcion llamada 'saludar'
    print("Hola, me despido desde una funcion del modulo <despedidas> del subpaquete <adios>")

class Despedir(): # Clase llamada 'Saludo'
    def __init__(self):
        print("Chau, me despido desde una clase del modulo <despedidas> del subpaquete <adios>.")